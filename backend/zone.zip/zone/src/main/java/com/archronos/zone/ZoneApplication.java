package com.archronos.zone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZoneApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZoneApplication.class, args);
	}

}
